#include<stdio.h>
#include<string.h>

 
int main(){
	char *a = "I am student";
	char *b = a;
	puts(b);
	return 0;
}
