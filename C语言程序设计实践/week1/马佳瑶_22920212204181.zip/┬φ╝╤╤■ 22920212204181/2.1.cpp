#include<stdio.h>
#include<string.h>
 
int main(){
	char *s = "I love China!";
	puts(s);
	return 0;
}
