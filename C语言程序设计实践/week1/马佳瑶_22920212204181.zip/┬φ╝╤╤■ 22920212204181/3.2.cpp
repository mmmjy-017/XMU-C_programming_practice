#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>



int main() {
	char x = 0xfe;
	int y = 0x0001;
	printf("%d",x | y);
	
	return 0;
}
